
public class Kosoctverec {

	private int strana;
	private int uhel;
	private int obvod;
	private double vyska;

	// Strany
	public int getStrana() {
		return strana;
	}

	public void setStrana(int novaStrana) {
		this.strana = novaStrana;
	}

	// Uhel
	public int getUhel() {
		return uhel;
	}

	public void setUhel(int novyUhel) {
		this.uhel = novyUhel;
	}

	// Obvod
	public int getObvod() {
		return obvod;
	}

	public void setObvod(int novyObvod) {
		this.obvod = novyObvod;
	}
	// Vyska

	public double getVyska() {
		return vyska;
	}

	public void setVyska(double novaVyska) {
		this.vyska = novaVyska;
	}

}

