public class Main {

	public static void main(String[] args) {
		// Prvn� �kol
		Mesto Praha = new Mesto();
		Mesto Brno = new Mesto();

		Praha.setJmeno("Praha");
		Praha.setPocetobyvatel(1324277);
		Praha.setRozloha(496);

		System.out.println(Praha.getJmeno() + " m� hustotu zalidn�n�: " + Praha.getRozloha());

		Brno.setJmeno("Brno");
		Brno.setPocetobyvatel(381346);
		Brno.setRozloha(230);

		System.out.println(Brno.getJmeno() + " m� hustotu zalidn�n�: " + Brno.getRozloha());

		System.out.println();
		// Druh� �kol
		Kosoctverec K1 = new Kosoctverec();
		K1.setStrana(10);
		K1.setUhel(60);
		K1.setObvod(K1.getStrana() * 4);
		K1.setVyska(K1.getStrana() * Math.sin(-K1.getUhel()));

		System.out.println("Koso�tverec o stran� " + K1.getStrana() + " s �hlem " + K1.getUhel() + " m� obvod "
				+ K1.getObvod() + " a v��ku " + K1.getVyska());
		K1.setStrana(5);
		System.out.println("Koso�tverec o stran� " + K1.getStrana() + " s �hlem " + K1.getUhel() + " m� obvod "
				+ K1.getObvod() + " a v��ku " + K1.getVyska());

		System.out.println();
		// T�et� �kol
		Tvor Bumbrlicek = new Tvor();
		Tvor Truhlik = new Tvor();

		Bumbrlicek.setSila(5);
		Truhlik.setSila(7);

		System.out.println("Bumrlicek m� s�lu: " + Bumbrlicek.getSila());
		System.out.println("Truhl�k m� s�lu: " + Truhlik.getSila());

		if (Bumbrlicek.getSila() < Truhlik.getSila()) {
			System.out.println("Vyhr�l Truhl�k!");
		} else {
			System.out.println("Vyhr�l Bumbrl��ek");
		}

		System.out.println();
		// �tvrt� �kol
		
		int C1b = 32;
		int C4b = 26;
		
		System.out.println("T��da C1b m� " + C1b + " ��k�");
		System.out.println("T��da C1b m� " + C4b + " ��k�");
		
		
		
	}

}