
public class Tvor {

	private int sila;
	
	public int getSila() {
		return sila;
	}
	public void setSila(int novaSila) {
		this.sila = novaSila;
	}
}

