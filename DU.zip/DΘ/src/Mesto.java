
public class Mesto {

	private String jmeno;
	private int pocetobyvatel;
	private int rozloha;

	public double hustota() {
		return getPocetobyvatel() / getRozloha();
	}

	public int getPocetobyvatel() {
		return pocetobyvatel;
	}

	public void setPocetobyvatel(int pocetobyvatel) {
		this.pocetobyvatel = pocetobyvatel;
	}

	public int getRozloha() {
		return rozloha;
	}

	public void setRozloha(int rozloha) {
		this.rozloha = rozloha;
	}

	public String getJmeno() {
		return jmeno;
	}

	public void setJmeno(String jmeno) {
		this.jmeno = jmeno;
	}
}