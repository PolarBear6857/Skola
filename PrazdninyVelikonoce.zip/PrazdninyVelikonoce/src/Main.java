import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void vypisSeznamu(ArrayList<Integer> celaCisla) {
		for (int i = 0; i < celaCisla.size(); i++) {
			System.out.print(celaCisla.get(i) + ",");
		}
		System.out.println();
	}

	public static ArrayList<Integer> seznamKlesajicichCisel(ArrayList<Integer> celaCisla, int pozice) {
		ArrayList<Integer> vysledek = new ArrayList<>();
		int cislo = celaCisla.get(pozice);
		while (true) {
			if ((pozice + 1) < celaCisla.size()) {
				int dalsiCislo = celaCisla.get(pozice + 1);
				if (dalsiCislo < cislo) {
					if (vysledek.isEmpty()) {
						vysledek.add(cislo);
					}
					vysledek.add(dalsiCislo);
					cislo = dalsiCislo;
					pozice++;
				} else {
					return vysledek;
				}
			} else {
				return vysledek;
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> celaCisla = new ArrayList<>();

		System.out.println("Zadejte po�et ��sel");
		int zadanaSize = sc.nextInt();
		sc.nextLine();

		for (int i = 0; i < zadanaSize; i++) {
			System.out.println("Zadejte " + (i + 1) + ". ��slo");
			int cislo = sc.nextInt();
			sc.nextLine();
			celaCisla.add(cislo);
		}

		int soucetKladnychCisel = 0;

		for (int i = 0; i < celaCisla.size(); i++) {
			if (celaCisla.get(i) > 0) {
				soucetKladnychCisel = celaCisla.get(i) + soucetKladnychCisel;
			}
		}

		System.out.println("Sou�et kladn�ch ��sel je: " + soucetKladnychCisel);

		int nejvetsiZaporneCisloPomoc = -999999999;
		int nejvetsiZaporneCislo = 0;
		for (int i = 0; i < celaCisla.size(); i++) {
			if (celaCisla.get(i) > nejvetsiZaporneCisloPomoc && celaCisla.get(i) < 0) {
				nejvetsiZaporneCislo = celaCisla.get(i);
			}
		}

		System.out.println("Nejv�t�� z�porn� ��slo je: " + nejvetsiZaporneCislo);

		ArrayList<Integer> nejdelsiSeznamKlesajicichCisel = new ArrayList<>();

		for (int i = 0; i < celaCisla.size(); i++) {

			ArrayList<Integer> tmp = seznamKlesajicichCisel(celaCisla, i);
			if (tmp.size() > nejdelsiSeznamKlesajicichCisel.size()) {
				nejdelsiSeznamKlesajicichCisel = tmp;
			}
		}

		vypisSeznamu(nejdelsiSeznamKlesajicichCisel);

		System.out.println("___________________________________________");

		Ucet u = new Ucet(sc);

		while (u.nabidka())
			;

	}
}
