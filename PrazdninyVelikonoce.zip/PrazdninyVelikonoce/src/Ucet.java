import java.util.ArrayList;
import java.util.Scanner;

public class Ucet {

	private String jmeno;
	private String prijmeni;
	private double zustatek;
	private final ArrayList<Double> seznamTransakci = new ArrayList<>();
	private final Scanner sc;

	public Ucet(Scanner sc) {
		this.sc = sc;
	}

	public String getJmeno() {
		return jmeno;
	}

	public void setJmeno(String jmeno) {
		this.jmeno = jmeno;
	}

	public String getPrijmeni() {
		return prijmeni;
	}

	public void setPrijmeni(String prijmeni) {
		this.prijmeni = prijmeni;
	}

	public double getZustatek() {
		return zustatek;
	}

	public void vklad(double castka) {
		if (castka <= 0) {
			System.out.println("Lze vlo�it pouze ��stku v�t�� ne� 0");
		} else {
			zustatek = zustatek + castka;
			seznamTransakci.add(castka);
			zobrazitZustatek();
		}
	}

	public void vyber(double castka) {
		if (castka <= 0) {
			System.out.println("Lze vybrat pouze ��stku v�t�� ne� 0");
		} else {
			if (castka > zustatek) {
				System.out.println("Na ��tu nen� dostatek pen�z");
				return;
			} else {
				zustatek = zustatek - castka;
				seznamTransakci.add(-castka);
				zobrazitZustatek();
			}
		}
	}

	public void zobrazitZustatek() {
		System.out.println("V� z�statek: " + zustatek);
	}

	public double getNejvyssiVklad() {
		double nejvyssiVklad = 0.0;
		for (Double castka : seznamTransakci) {
			if (castka > 0) {
				if (castka > nejvyssiVklad) {
					nejvyssiVklad = castka;
				}
			}
		}
		return nejvyssiVklad;
	}

	public double getNejvyssiVyber() {
		double nejvyssiVyber = 0.0;
		for (Double castka : seznamTransakci) {
			if (castka < 0) {
				castka = -castka;
				if (castka > nejvyssiVyber) {
					nejvyssiVyber = castka;
				}
			}
		}
		return nejvyssiVyber;
	}

	public boolean nabidka() {
		System.out.println("Vyberte mo�nost:");
		System.out.println("1) V�pis z�statku na ��tu");
		System.out.println("2) Vklad na ��et");
		System.out.println("3) V�b�r z ��tu");
		System.out.println("4) V�pis nejvy��� ��stky, kter� byla vlo�ena na ��et");
		System.out.println("5) V�pis nejvy��� ��stky, kter� byla z ��tu vybr�na");
		System.out.println("6) Konec");
		String moznost = sc.nextLine();
		if ("1".equals(moznost)) {
			zobrazitZustatek();
		} else if ("2".equals(moznost)) {
			System.out.println("Zadejte ��stku:");
			double castka = sc.nextDouble();
			sc.nextLine();
			vklad(castka);
		} else if ("3".equals(moznost)) {
			System.out.println("Zadejte ��stku:");
			double castka = sc.nextDouble();
			sc.nextLine();
			vyber(castka);
		} else if ("4".equals(moznost)) {
			double nejvyssiVklad = getNejvyssiVklad();
			if (nejvyssiVklad > 0) {
				System.out.println("Nejvy��� vlo�en� ��stka: " + nejvyssiVklad);
			} else {
				System.out.println("Je�t� nebyla vlo�ena ��dn� ��stka");
			}
		} else if ("5".equals(moznost)) {
			double nejvyssiVyber = getNejvyssiVyber();
			if (nejvyssiVyber > 0) {
				System.out.println("Nejvy��� vybran� ��stka: " + nejvyssiVyber);
			} else {
				System.out.println("Je�t� nebyla vlo�ena ��dn� ��stka");
			}
		} else if ("6".equals(moznost)) {
			return false;
		} else {
			System.out.println("Neplatn� mo�nost");
		}
		return true;
	}

}
