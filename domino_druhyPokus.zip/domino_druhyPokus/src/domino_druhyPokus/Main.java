package domino_druhyPokus;

import java.util.Scanner;

import java.util.ArrayList;
import java.util.Random;

//P�i programov�n� jsem vyu�il tro�ku pomoc od ta�ky xD

public class Main {

	private static ArrayList<Kostka> kostky = new ArrayList<>();
	private static Kostka prvniKostkaVRade = null;
	private static Kostka posledniKostkaVRade = null;

	private static void vyberKostky(Scanner sc) {
		while (true) {
			Kostka.vypsatRadu(prvniKostkaVRade);
			System.out.println("V�b�r kostek:");
			for (int i = 0; i < kostky.size(); i++) {
				System.out.println("��slo " + (i) + ": " + kostky.get(i));
			}
			System.out.println("Zadejte ��slo kostky:");
			int cisloKostky = sc.nextInt();
			sc.nextLine();
			if ((cisloKostky >= 0) && (cisloKostky < kostky.size())) {
				Kostka kostka = kostky.get(cisloKostky);
				if (prvniKostkaVRade == null) {
					prvniKostkaVRade = kostka;
					posledniKostkaVRade = kostka;
					kostky.remove(cisloKostky);
					return;
				} else {
					System.out.println(
							"Pokud chcete kostku p�i�adit na za��tek �ady, stiskn�te Z, pokud na konec �ady, tak sstikn�te K");
					String strana = sc.nextLine();
					strana = strana.toLowerCase();
					if (strana.equals("z")) {
						if (prvniKostkaVRade.pripojitKostkuNaStranu1(kostka)) {
							kostka.setStrana2Kostka(prvniKostkaVRade);
							prvniKostkaVRade = kostka;
							kostky.remove(cisloKostky);
							return;
						} else {
							System.out.println("Vybranou kostku nelze p�i�adit na za��tek �ady");
						}
					} else if (strana.equals("k")) {
						if (posledniKostkaVRade.pripojitKostkuNaStranu2(kostka)) {
							kostka.setStrana1Kostka(posledniKostkaVRade);
							posledniKostkaVRade = kostka;
							kostky.remove(cisloKostky);
							return;
						} else {
							System.out.println("Vynranou kostku nelze p�i�adit na konec �ady");
						}
					} else {
						System.out.println("Neplatn� volba");
					}
				}
			} else {
				System.out.println("Zadali jste neplatn� ��slo");
			}
		}
	}

	public static boolean hracMaPlatneKostky() {
		if (prvniKostkaVRade == null) {
			return true;
		}
		for (Kostka kostka : kostky) {
			if (prvniKostkaVRade.platnaKostkaProStranu1(kostka)) {
				return true;
			} else if (posledniKostkaVRade.platnaKostkaProStranu2(kostka)) {
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		Random rand = new Random();

		int pocetKostek;
		while (true) {
			System.out.println("Zadejte po�et kostek domina (1 - 10)");
			pocetKostek = sc.nextInt();
			sc.nextLine();
			if (pocetKostek > 0 && pocetKostek < 11) {
				break;
			}
		}
		for (int i = 0; i < pocetKostek; i++) {
			int leva = rand.nextInt(6) + 1;
			int prava = rand.nextInt(6) + 1;
			Kostka k = new Kostka(leva, prava);
			kostky.add(k);
		}

		while (hracMaPlatneKostky()) {
			vyberKostky(sc);

		}
		Kostka.vypsatRadu(prvniKostkaVRade);
		if (kostky.size() == 0) {
			System.out.println("�sp�n� jste p�i�adil v�echny kostky");
		} else {
			System.out.println("Nem�te ��dne dal�� kostky, kter� by se daly p�i�adit");
			System.out.print("Zbyl� kostky: ");
			for (Kostka kostka : kostky) {
				System.out.print(kostka);
			}
		}

	}

}
