package domino_druhyPokus;

public class Kostka {

	private int strana1Cislo;
	private Kostka strana1Kostka;
	private int strana2Cislo;
	private Kostka strana2Kostka;

	public Kostka(int strana1Cislo, int strana2Cislo) {
		this.strana1Cislo = strana1Cislo;
		this.strana2Cislo = strana2Cislo;
	}

	public int getStrana1Cislo() {
		return strana1Cislo;
	}

	public void setStrana1Cislo(int strana1Cislo) {
		this.strana1Cislo = strana1Cislo;
	}

	public Kostka getStrana1Kostka() {
		return strana1Kostka;
	}

	public void setStrana1Kostka(Kostka strana1Kostka) {
		this.strana1Kostka = strana1Kostka;
	}

	public int getStrana2Cislo() {
		return strana2Cislo;
	}

	public void setStrana2Cislo(int strana2Cislo) {
		this.strana2Cislo = strana2Cislo;
	}

	public Kostka getStrana2Kostka() {
		return strana2Kostka;
	}

	public void setStrana2Kostka(Kostka strana2Kostka) {
		this.strana2Kostka = strana2Kostka;
	}

	private void otocitCisla() {
		int tmpCislo = strana1Cislo;
		strana1Cislo = strana2Cislo;
		strana2Cislo = tmpCislo;
	}

	public boolean platnaKostkaProStranu1(Kostka neprirazenaKostka) {
		if (strana1Cislo == neprirazenaKostka.strana2Cislo) {
			return true;
		} else if (strana1Cislo == neprirazenaKostka.strana1Cislo) {
			return true;
		}
		return false;
	}

	public boolean platnaKostkaProStranu2(Kostka neprirazenaKostka) {
		if (strana2Cislo == neprirazenaKostka.strana1Cislo) {
			return true;
		} else if (strana2Cislo == neprirazenaKostka.strana2Cislo) {
			return true;
		}
		return false;
	}

	public boolean pripojitKostkuNaStranu1(Kostka neprirazenaKostka) {
		if (strana1Kostka == null) {
			if (strana1Cislo == neprirazenaKostka.strana2Cislo) {
				strana1Kostka = neprirazenaKostka;
				return true;
			} else if (strana1Cislo == neprirazenaKostka.strana1Cislo) {
				neprirazenaKostka.otocitCisla();
				strana1Kostka = neprirazenaKostka;
				return true;
			}

		}
		return false;
	}

	public boolean pripojitKostkuNaStranu2(Kostka neprirazenaKostka) {
		if (strana2Kostka == null) {
			if (strana2Cislo == neprirazenaKostka.strana1Cislo) {
				strana2Kostka = neprirazenaKostka;
				return true;
			} else if (strana2Cislo == neprirazenaKostka.strana2Cislo) {
				neprirazenaKostka.otocitCisla();
				strana2Kostka = neprirazenaKostka;
				return true;
			}

		}
		return false;
	}

	public String toString() {
		return "[ " + strana1Cislo + " | " + strana2Cislo + " ]";
	}

	public static void vypsatRadu(Kostka prvniKostkaVRade) {
		if (prvniKostkaVRade != null) {
			System.out.print("�ada: ");
			Kostka kostka = prvniKostkaVRade;
			while (kostka != null) {
				System.out.print(kostka);
				kostka = kostka.strana2Kostka;
			}
			System.out.println();
		}
	}
}
