
public class Koule {
	private double polomer;

	public double getPolomer() {
		return polomer;
	}

	public void setPolomer(int novyPolomer) {
		this.polomer = novyPolomer;
	}
	public double objem() {
		return (4/3) * (3.14 * polomer * polomer * polomer);
	}
	public double povrch() {
		return 4 * 3.14 * polomer * polomer;
	}
}
