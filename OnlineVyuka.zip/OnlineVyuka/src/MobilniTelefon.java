
public class MobilniTelefon {
	private String znacka;
	private double uhlopricka;
	private String operacniSystem;

	public MobilniTelefon(String zn, double uh, String os) {
		znacka = zn;
		uhlopricka = uh;
		operacniSystem = os;
	}
}
