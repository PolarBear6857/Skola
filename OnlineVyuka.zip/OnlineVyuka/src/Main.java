import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//koule	
		Koule K1 = new Koule();
		Scanner sc = new Scanner(System.in);
		System.out.println("Zadejte polom�r koule");
		int Polomer = sc.nextInt();
		K1.setPolomer(Polomer);
		System.out.println("objem koule je " + K1.objem() + " cm3");
		System.out.println("povrch koule je " + K1.povrch() + " cm2");

//mobil
		sc.nextLine();
		System.out.print("Zadejte zna�ku:");
		String zn = sc.nextLine();

		System.out.print("Zadejte uhlop���ku:");
		double uh = sc.nextDouble();
		sc.nextLine();
		System.out.print("Zadejte opera�n� syst�m:");
		String os = sc.nextLine();

		MobilniTelefon MT1 = new MobilniTelefon(zn, uh, os);
		System.out.println(zn + uh + os);
		sc.close();

	}

}
