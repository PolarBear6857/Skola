import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		ArrayList<Animal> zvirata = new ArrayList<>();

		System.out.println();
		System.out.println("Zadejte po�et ps�");
		int pocetPsu = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < pocetPsu; i++) {
			Dog pes = new Dog();
			System.out.println("Zadejte jm�no");
			pes.setName(sc.nextLine());
			System.out.println("Zadejte rasu");
			pes.setRace(sc.nextLine());
			zvirata.add(pes);
		}

		System.out.println();
		System.out.println("Zadejte po�et prasat");
		int pocetPrasat = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < pocetPrasat; i++) {
			Pig prase = new Pig();
			System.out.println("Zadejte v�hu");
			prase.setWeight(sc.nextInt());
			sc.nextLine();
			zvirata.add(prase);
		}

		System.out.println();
		System.out.println("Zadejte po�et pt�k�");
		int pocetPtaku = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < pocetPtaku; i++) {
			Bird ptak = new Bird();
			System.out.println("Zadejte druh");
			ptak.setTypeOfBird(sc.nextLine());
			zvirata.add(ptak);
		}

		int psiZvuk = 0;
		int praseciZvuk = 0;
		int ptaciZvuk = 0;
		for (int i = 0; i < zvirata.size(); i++) {
			if (zvirata.get(i).animalSound().equals("Haf, haf, haf")) {
				psiZvuk++;
			} else if (zvirata.get(i).animalSound().equals("Chro, chro, chro")) {
				praseciZvuk++;
			} else if (zvirata.get(i).animalSound().equals("P�p, p�p, p�p")) {
				ptaciZvuk++;
			}
		}

		System.out.println();

		for (int i = 0; i < zvirata.size(); i++) {
			System.out.println(zvirata.get(i).toString());
		}

		System.out.println();

		if (psiZvuk >= 1) {
			System.out.println("V ArrayListu se objevuje zvuk Haf, haf, haf");
		}
		if (praseciZvuk >= 1) {
			System.out.println("V ArrayListu se objevuje zvuk Chro, chro, chro");
		}
		if (ptaciZvuk >= 1) {
			System.out.println("V ArrayListu se objevuje zvuk P�p, p�p, p�p");
		}

		System.out.println();
		System.out.println("_____________________________________________");
		System.out.println();

		ArrayList<Student> studenti = new ArrayList<>();

		System.out.println("Kolik chcete zadat student�?");
		int pocetStudentu = sc.nextInt();
		sc.nextLine();

		for (int i = 0; i < pocetStudentu; i++) {
			Student s = new Student();
			System.out.println("Zadejte jm�no");
			s.setJmeno(sc.nextLine());
			System.out.println("Zadejte p��jmen�");
			s.setPrijmeni(sc.nextLine());
			System.out.println("Zadejte pr�m�r zn�mek");
			s.setPrumerZnamek(sc.nextDouble());
			sc.nextLine();
			studenti.add(s);
		}

		Collections.sort(studenti);

		for (Student student : studenti) {
			System.out.println(student);
		}

	}

}
