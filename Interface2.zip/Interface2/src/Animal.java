
public interface Animal {

	public String animalSound();
}
