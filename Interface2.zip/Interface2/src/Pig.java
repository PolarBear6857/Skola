
public class Pig implements Animal {

	private int weight;

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	@Override
	public String animalSound() {
		return "Chro, chro, chro";
	}

	public String toString() {
		return "Prase v�� " + weight + " kg a d�l� " + animalSound();
	}

}
