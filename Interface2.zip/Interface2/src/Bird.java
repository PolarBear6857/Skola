
public class Bird implements Animal{

	private String typeOfBird;

	public String getTypeOfBird() {
		return typeOfBird;
	}

	public void setTypeOfBird(String typeOfBird) {
		this.typeOfBird = typeOfBird;
	}

	@Override
	public String animalSound() {
		return "P�p, p�p, p�p";
	}
	
	public String toString() {
		return "Pt�k druhu " + typeOfBird + " d�l� " + animalSound();
	}
	
	
	
}
