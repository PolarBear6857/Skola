
public class Student implements Comparable<Student> {

	private String jmeno;
	private String prijmeni;
	private double prumerZnamek;

	public String getJmeno() {
		return jmeno;
	}

	public void setJmeno(String jmeno) {
		this.jmeno = jmeno;
	}

	public String getPrijmeni() {
		return prijmeni;
	}

	public void setPrijmeni(String prijmeni) {
		this.prijmeni = prijmeni;
	}

	public double getPrumerZnamek() {
		return prumerZnamek;
	}

	public void setPrumerZnamek(double prumerZnamek) {
		this.prumerZnamek = prumerZnamek;
	}

	public String toString() {
		return jmeno + prijmeni + " m� pr�m�r zn�mek " + prumerZnamek;
	}

	@Override
	public int compareTo(Student o) {
		int c = Double.compare(this.prumerZnamek, o.prumerZnamek);
		if (c == 0) {
			c = this.prijmeni.compareTo(o.getPrijmeni());
		}
		return c;
	}
}
