
public class Dog implements Animal {

	private String name;
	private String race;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	@Override
	public String animalSound() {
		return "Haf, haf, haf";
	}
	
	public String toString() {
		return "Pes m� jm�no " + name + ", rasu " + race + " a d�l� " + animalSound();
	}

}
