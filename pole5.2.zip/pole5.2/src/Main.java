import java.util.Scanner;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		Random rand = new Random();

		System.out.println("CVI�EN� 1");
		System.out.println();

		String[] list = new String[7];
		int index = 0;

		for (int i = 0; i < list.length; i++) {
			System.out.println("Zadejte textov� �et�zec:");
			list[index] = sc.nextLine();
			index++;
		}
		for (int i = 0; i < list.length; i++) {
			System.out.println("Text:" + list[i]);
		}

		System.out.println();
		System.out.println("____________________________");

		System.out.println("CVI�EN� 2");
		System.out.println();
		System.out.println("Vygenerovan� ��sla:");

		int[] pole = new int[10];
		for (int i = 0; i < pole.length; i++) {

			pole[i] = rand.nextInt(201) - 100;
		}
		System.out.println("Vyps�n� pole");
		for (int i = 0; i < pole.length; i++) {
			System.out.println(pole[i]);
		}
		System.out.println();
		System.out.println("Vyps�n� pole pozp�tku");
		for (int i = pole.length - 1; i >= 0; i--) {
			System.out.println(pole[i]);
		}

		System.out.println();
		System.out.println("Vyps�n� pole v po�ad� kladn� ��sla, z�porn� ��sla a nuly");
		for (int i = 0; i < pole.length; i++) {
			if (pole[i] > 0) {
				System.out.println(pole[i]);
			}
		}
		for (int i = 0; i < pole.length; i++) {
			if (pole[i] < 0) {
				System.out.println(pole[i]);
			}
		}
		for (int i = 0; i < pole.length; i++) {
			if (pole[i] == 0) {
				System.out.println(pole[i]);
			}
		}
		System.out.println();
		System.out.println("Vyps�n� jednocifern�ch ��sel");
		boolean nalezeno = false;
		for (int i = 0; i < pole.length; i++) {
			if ((pole[i] > -10) && (pole[i] < 10)) {
				nalezeno = true;
				System.out.println(pole[i]);
			}
		}
		if (!nalezeno) {
			System.out.println("Nebyla nalezena jednocifern� ��sla");
		}
		int soucet = 0;
		for (int i = 0; i < pole.length; i++) {
			soucet += pole[i];

		}
		double prumer = (double) soucet / pole.length;
		System.out.println("Pr�m�r je: " + prumer);
		double prah1 = prumer - 0.2 * Math.abs(prumer);
		double prah2 = prumer + 0.2 * Math.abs(prumer);
		int nejblizsiHodnota = 0;
		double nejblizsiVzdalenost = Double.MAX_VALUE;
		for (int i = 0; i < pole.length; i++) {
			if ((pole[i] < prah1) || (pole[i] > prah2)) {
				System.out.println("Hodnota " + pole[i] + " se li�� o v�ce ne� 20% od pr�m�ru");
			}
			double vzdalenost;
			if (pole[i] > prumer) {
				vzdalenost = pole[i] - prumer;
			} else {
				vzdalenost = prumer - pole[i];
			}
			if (vzdalenost < nejblizsiVzdalenost) {
				nejblizsiVzdalenost = vzdalenost;
				nejblizsiHodnota = pole[i];
			}
		}
		System.out.println("Hodnota nejbli��� pr�m�ru je " + nejblizsiHodnota);
	}

}
