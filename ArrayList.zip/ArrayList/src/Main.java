import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("CVI�EN� 1");
		System.out.println();

		ArrayList<Integer> listCisel = new ArrayList<Integer>();

		while (true) {
			System.out.println("Zadejte ��slo(ukon�ete nulou)");
			int cislo = sc.nextInt();
			sc.nextLine();
			if (cislo == 0) {
				break;
			}
			if (cislo < 0) {
				System.out.println("Nelze zadat z�porn� ��slo");
				break;
			}
			listCisel.add(cislo);

		}

		System.out.println(listCisel);

		System.out.println("Sud� ��sla");
		for (int i = 0; i < listCisel.size(); i++) {
			if (listCisel.get(i) % 2 == 0) {
				System.out.print(listCisel.get(i) + ",");
			}
		}

		int suma = 0;
		int soucet = 0;
		for (int i = 0; i < listCisel.size(); i++) {
			soucet = soucet + listCisel.get(i);
			suma++;
		}
		System.out.println();
		System.out.println("Pr�m�r v�ech ��sel je: " + ((double) soucet / suma));

		int nejvetsiCislo = listCisel.get(0);
		for (int i = 1; i < listCisel.size(); i++) {
			if (listCisel.get(i) > nejvetsiCislo) {
				nejvetsiCislo = listCisel.get(i);
			}
		}

		Collections.sort(listCisel);
		System.out.println("2. nejmen�� ��slo: " + listCisel.get(1));

		System.out.println("Nejv�t�� ��slo je: " + nejvetsiCislo);

		System.out.println("___________________________________");
		System.out.println("CVI�EN� 2");
		System.out.println();

		ArrayList<Kniha> knihovna = new ArrayList<Kniha>();
		knihovna.add(new Kniha("Metro 2033", 100, "Dmitry", "Glukhovsky"));
		knihovna.add(new Kniha("Mar�an", 130, "Andy", "Weir"));
		knihovna.add(new Kniha("Parazit", 165, "David", "Koepp"));
		knihovna.add(new Kniha("ڞasn� Zem�plocha", 110, "Terry", "Pratchett"));

		for (int i = 0; i < knihovna.size(); i++) {
			System.out.println(knihovna.get(i));
		}
		int pocetKnih = 0;
		int celkovaCena = 0;
		for (int i = 0; i < knihovna.size(); i++) {
			celkovaCena = celkovaCena + knihovna.get(i).getCena();
		}

		System.out.println("Pr�m�r cen knih je: " + ((double) celkovaCena / pocetKnih));

		System.out.println("___________________________________");
		System.out.println("CVI�EN� 3");
		System.out.println();

		ArrayList<Uzivatel> seznamUzivatelu = new ArrayList<Uzivatel>();
		while (true) {
			System.out.println("Zadejte u�ivatelsk� jm�no (pr�zdn� �et�zec ukon�� zad�v�n�)");
			String uzivatelskeJmeno = sc.nextLine();
			if (uzivatelskeJmeno.isEmpty()) {
				break;
			}
			boolean uzivatelskeJmenoExistuje = false;
			for (Uzivatel uzivatel : seznamUzivatelu) {
				if (uzivatelskeJmeno.equals(uzivatel.getUzivatelskeJmeno())) {
					System.out.println("Toto u�ivatelsk� jm�no se ji� pou��v�");
					uzivatelskeJmenoExistuje = true;
					break;
				}
			}

			if (uzivatelskeJmenoExistuje) {
				continue;
			}
			System.out.println("Zadejte heslo");
			String heslo = sc.nextLine();

			seznamUzivatelu.add(new Uzivatel(uzivatelskeJmeno, heslo));

		}
		for (int i = 0; i < seznamUzivatelu.size(); i++) {
			System.out.println(seznamUzivatelu.get(i));
		}

	}

}
