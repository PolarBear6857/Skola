
public class Kniha {

	private String nazevKnihy;
	private int cena;
	private String autorJmeno;
	private String autorPrijmeni;

	public Kniha(String nazevKnihy, int cena, String autorJmeno, String autorPrijmeni) {
		this.nazevKnihy = nazevKnihy;
		this.cena = cena;
		this.autorJmeno = autorJmeno;
		this.autorPrijmeni = autorPrijmeni;
	}

	public String getNazevKnihy() {
		return nazevKnihy;
	}

	public void setNazevKnihy(String nazevKnihy) {
		this.nazevKnihy = nazevKnihy;
	}

	public int getCena() {
		return cena;
	}

	public void setCena(int cena) {
		this.cena = cena;
	}

	public String getAutorJmeno() {
		return autorJmeno;
	}

	public void setAutorJmeno(String autorJmeno) {
		this.autorJmeno = autorJmeno;
	}

	public String getAutorPrijmeni() {
		return autorPrijmeni;
	}

	public void setAutorPrijmeni(String autorPrijmeni) {
		this.autorPrijmeni = autorPrijmeni;
	}

	public String toString() {
		return nazevKnihy + " stoj� " + cena + " k� a napsal ji " + autorJmeno + " " + autorPrijmeni;
	}
}
