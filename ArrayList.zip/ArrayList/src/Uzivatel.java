
public class Uzivatel {

	private String uzivatelskeJmeno;
	private String heslo;
	
	public Uzivatel(String uzivatelskeJmeno, String heslo) {
		this.uzivatelskeJmeno = uzivatelskeJmeno;
		this.heslo = heslo;
	}
	
	public String getUzivatelskeJmeno() {
		return uzivatelskeJmeno;
	}
	
	public void setUzivatelskeJmeno(String uzivatelskeJmeno) {
		this.uzivatelskeJmeno = uzivatelskeJmeno;
	}
	
	public String getHeslo() {
		return heslo;
	}
	
	public void setHeslo(String heslo) {
		this.heslo = heslo;
	}
	
	public String toString() {
		return "U�ivatelsk� jm�no: "  + uzivatelskeJmeno + ", heslo: " + heslo;
	}
}
