
public class Zvire {

	private int hmotnost;
	private int vek;

	public Zvire(int hmotnost, int vek) {
		super();
		this.hmotnost = hmotnost;
		this.vek = vek;

	}

	public int getHmotnost() {
		return hmotnost;
	}

	public void setHmotnost(int hmotnost) {
		this.hmotnost = hmotnost;
	}

	public int getVek() {
		return vek;
	}

	public void setVek(int vek) {
		this.vek = vek;
	}

	public String vydejZvuk() {
		return "Vrrr";
	}

	public String toString() {
		return "Zv��e v�� " + hmotnost + " kg, je star� " + vek + " a d�l� " + vydejZvuk();
	}
}
