import java.util.Random;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("CVI�EN� 1");
		System.out.println();
		String poleSlov[] = { "krakatit", "traktor", "auto", "mravenec", "baterka", "rez", "srnka", "leporelo", "auto",
				"mravenec", "Auto", "automobil", "traktor", "auto" };

		// v�pis po�tu prvk�
		System.out.println("Po�et prvk� v poli: " + poleSlov.length);
		System.out.println();
		// v�pis pole
		System.out.println("V�pis pole:");
		for (int i = 0; i < poleSlov.length; i++) {
			System.out.println(poleSlov[i]);
		}
		System.out.println();
		// v�pis po�tu slov auto
		int auto = 0;
		for (int i = 0; i < poleSlov.length; i++) {
			if (poleSlov[i].equals("auto")) {
				auto++;
			}
		}
		System.out.println("Po�et slov auto: " + auto);
		System.out.println();
		// v�pis slov s d�lkou 7 znak�
		System.out.println("Slova o 7 znac�ch:");
		for (int i = 0; i < poleSlov.length; i++) {
			if (poleSlov[i].length() == 7) {
				System.out.println(poleSlov[i]);
			}
		}

		System.out.println("_____________________________");
		System.out.println("CVI�EN� 2");
		System.out.println();

		// pole pro 10 ��sel
		Random rand = new Random();
		int[] pole = new int[10];
		for (int i = 0; i < pole.length; i++) {
			pole[i] = rand.nextInt(100) + 1;
		}

		System.out.println("Pole");
		for (int i = 0; i < pole.length; i++) {
			System.out.print(pole[i] + ",");
		}
		System.out.println();
		System.out.println();
		// sud� ��sla
		System.out.println("Sud� ��sla");
		for (int i = 0; i < pole.length; i++) {
			if (pole[i] % 2 == 0) {
				System.out.print(pole[i] + ",");
			}
		}
		System.out.println();
		System.out.println();
		// lich� ��sla
		System.out.println("Lich� ��sla");
		for (int i = 0; i < pole.length; i++) {
			if (pole[i] % 2 != 0) {
				System.out.print(pole[i] + ",");
			}
		}
		System.out.println();
		System.out.println("_____________________________");
		System.out.println("CVI�EN� 3");
		System.out.println();

		Zvire[] zvire = { new Pes(35, 7, "vlcak"), new Pes(8, 3, "jezevcik"), new Kocka(4, 4, "Micka"),
				new Kocka(3, 2, "Mourek"), new Pes(45, 4, "tibetska doga"), new Pes(25, 6, "setr"),
				new Kocka(2, 3, "Liza"), new Pes(7, 10, "jezevcik") };

		System.out.println();

		int jezevcik = 0;
		for (int i = 0; i < zvire.length; i++) {
			System.out.println(zvire[i].vydejZvuk());
			if ((zvire[i] instanceof Pes) && ((Pes) zvire[i]).getRasa().equals("jezevcik")) {
				jezevcik++;
			}
		}

		System.out.println();
		System.out.println("Po�et jezev��k� je: " + jezevcik);
		System.out.println();

		int nejmensiVek = zvire[0].getVek();
		Zvire nejmensiVekZvire = zvire[0];
		for (int i = 0; i < zvire.length; i++) {
			if (zvire[i].getVek() < nejmensiVek) {
				nejmensiVek = zvire[i].getVek();
				nejmensiVekZvire = zvire[i];
			}
		}

		System.out.println("Nejmen�� v�k je: " + nejmensiVek + ". " + nejmensiVekZvire);

	}

}
