
public class Kocka extends Zvire {

	private String jmeno;

	public String getJmeno() {
		return jmeno;
	}

	public void setJmeno(String jmeno) {
		this.jmeno = jmeno;
	}

	public Kocka(int hmotnost, int vek, String jmeno) {
		super(hmotnost, vek);
		this.jmeno = jmeno;
	}

	public String vydejZvuk() {
		return "M�au, M�au";
	}

	public String toString() {
		return super.toString() + " a jej� jm�no je " + jmeno;
	}

}
