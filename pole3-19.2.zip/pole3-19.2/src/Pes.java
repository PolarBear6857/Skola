
public class Pes extends Zvire {

	private String rasa;

	public String getRasa() {
		return rasa;
	}

	public void setRasa(String rasa) {
		this.rasa = rasa;
	}

	public Pes(int hmotnost, int vek, String rasa) {
		super(hmotnost, vek);
		this.rasa = rasa;

	}

	public String vydejZvuk() {
		return "Vrrr, haf, haf";
	}

	public String toString() {
		return super.toString() + " a jeho rasa je" + rasa;
	}

}
