
public class Napoj {

	private String nazev;
	private int cena;
	
	public Napoj(String nazev, int cena) {
		super();
		this.nazev = nazev;
		this.cena = cena;
	}
	
	public String getNazev() {
		return nazev;
	}
	
	public void setNazev(String nazev) {
		this.nazev = nazev;
	}
	
	public int getCena() {
		return cena;
	}
	
	public void setCena(int cena) {
		this.cena = cena;
	}
	
	public String toString() {
		return "N�poj " + nazev + " stoj� " + cena + " k�";
	}
}
