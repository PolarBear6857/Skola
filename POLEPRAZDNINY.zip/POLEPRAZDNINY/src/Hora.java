
public class Hora {

	private int vyska;
	private String jmeno;
	
	public Hora(int vyska, String jmeno) {
		this.vyska = vyska;
		this.jmeno = jmeno;
	}
	
	public int getVyska() {
		return vyska;
	}
	
	public void setVyska(int vyska) {
		this.vyska = vyska;
	}
	
	public String getJmeno() {
		return jmeno;
	}
	
	public void setJmeno(String jmeno) {
		this.jmeno = jmeno;
	}
	
	public String toString() {
		return "Hora " + jmeno + " m� v��ku " + vyska + " m.n.m.";
	}
}
