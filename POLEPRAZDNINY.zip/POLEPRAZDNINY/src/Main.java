import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		System.out.println("KAPITOLA 1, CVI�EN� 3");
		System.out.println();

		int[] pole = new int[10];

		for (int i = 0; i < pole.length; i++) {
			System.out.println("Zadejte " + (i + 1) + ". ��slo");
			pole[i] = sc.nextInt();
		}

		System.out.println();
		System.out.println("POLE");
		for (int i = 0; i < pole.length; i++) {
			System.out.print(pole[i] + ",");
		}

		System.out.println();
		System.out.println("Pr�m�r");
		int soucet = 0;
		int pocet = 0;

		for (int i = 0; i < pole.length; i++) {
			if (i % 2 != 0) {
				soucet = soucet + pole[i];
				pocet++;
			}
		}
		System.out.println("Pr�m�r je " + (double) soucet / pocet);

		System.out.println();
		System.out.println("Z�porn� ��sla");

		for (int i = 0; i < pole.length; i++) {
			if (pole[i] < 0) {
				System.out.print(pole[i] + ",");
			}
		}

		System.out.println();
		System.out.println("__________________________________");

		sc.nextLine();

		System.out.println("KAPITOLA 2, CVI�EN� 5");
		System.out.println();

		String[] text = new String[6];

		for (int i = 0; i < text.length; i++) {
			System.out.println("Zadejte " + (i + 1) + ". text");
			text[i] = sc.nextLine();
		}
		System.out.println();
		for (int i = 0; i < text.length; i++) {
			System.out.print(text[i] + ",");
		}
		System.out.println();
		System.out.println();
		System.out.println("Zadejte hledan� v�raz");
		String hledani = sc.nextLine();

		for (int i = 0; i < text.length; i++) {
			if (text[i].equals(hledani)) {
				System.out.println("Slovo " + text[i] + " se v poli nach�z�");
			}
		}

		System.out.println();
		System.out.println("__________________________________");

		System.out.println("KAPITOLA 3, CVI�EN� 1");
		System.out.println();

		System.out.println("Zadejte velikost pole");
		int pocetHor = sc.nextInt();

		Hora[] hory = new Hora[pocetHor];

		for (int i = 0; i < hory.length; i++) {
			System.out.println("Zadejte v��ku");
			int vyska = sc.nextInt();
			sc.nextLine();
			System.out.println("Zadejte jm�no");
			String nazev = sc.nextLine();
			Hora hora = new Hora(vyska, nazev);
			hory[i] = hora;
		}

		for (int i = 0; i < hory.length; i++) {
			System.out.print(hory[i].getJmeno() + ",");
		}
		System.out.println();
		int nejvetsiVyska = hory[0].getVyska();
		String jmeno = hory[0].getJmeno();
		for (int i = 1; i < hory.length; i++) {
			if (hory[i].getVyska() > nejvetsiVyska) {
				nejvetsiVyska = hory[i].getVyska();
				jmeno = hory[i].getJmeno();
			}
		}

		System.out.println("Nejvy��� hora m��� " + nejvetsiVyska + " metr� a jmenuje se " + jmeno);

		int soucetVysek = 0;
		int pocetObjektuHora = 0;

		for (int i = 0; i < hory.length; i++) {
			soucetVysek = soucetVysek + hory[i].getVyska();
			pocetObjektuHora++;
		}

		System.out.println("Pr�m�r v��ek je " + (double) soucetVysek / pocetObjektuHora + " metr�");

		System.out.println();
		System.out.println("__________________________________");

		System.out.println("KAPITOLA 4, CVI�EN� 1");
		System.out.println();

		Napoj[] napoj = { new Napoj("limonada", 25), new Napoj("mineralka", 28), new AlkoholickyNapoj("pivo", 30, 4),
				new AlkoholickyNapoj("vino", 150, 15), new Napoj("mleko", 29) };

		for (int i = 0; i < napoj.length; i++) {
			System.out.println(napoj[i]);
		}

		int celkovaCena = 0;

		for (int i = 0; i < napoj.length; i++) {
			celkovaCena = celkovaCena + napoj[i].getCena();
		}

		System.out.println("Celkov� cena je: " + celkovaCena + " k�");

	}

}
