
public class AlkoholickyNapoj extends Napoj {

	private int procentoAlkoholu;
	
	public AlkoholickyNapoj(String nazev, int cena, int procentoAlkoholu) {
		super(nazev, cena);
		this.procentoAlkoholu = procentoAlkoholu;
	}
	
	public int getProcentoAlkoholu() {
		return procentoAlkoholu;
	}
	
	public void setProcentoAlkoholu(int procentoAlkoholu) {
		this.procentoAlkoholu = procentoAlkoholu;
	}
	
	public String toString() {
		return super.toString() + " a obsahuje " + procentoAlkoholu + "% alkoholu";
	}
}
