import java.util.ArrayList;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random rand = new Random();

		System.out.println("Cvi�en� 1");
		System.out.println();

		ArrayList<String> citaty = new ArrayList<String>();
		citaty.add("�ij pro ka�kou sekundu, bez v�h�n�.");
		citaty.add("Ne� cokoliv vzd�, uv�dom si nejprve, pro� jsi s t�m za�al.");
		citaty.add("Nedopus�te, aby mal� h�dka zni�ila velk� p��telstv�.");
		citaty.add("Sna�me se ��t tak, aby na�� smrti litoval i majitel poh�ebn� slu�by.");
		citaty.add("P��tel je ten, kter� p�ich�z�, kdy� cel� sv�t ode�el.");
		citaty.add("�ijeme jenom jednou. Tak by to m�la b�t z�bava.");

		int nahodnyIndex = rand.nextInt(6);
		System.out.println(citaty.get(nahodnyIndex));

		System.out.println("_________________________________");
		System.out.println("Cvi�en� 2");
		System.out.println();

		ArrayList<Integer> listCisel = new ArrayList<Integer>();

		System.out.println("Seznam ��sel v�etn� z�porn�ch");
		for (int i = 0; i < 10; i++) {
			listCisel.add(rand.nextInt(41) - 20);
		}

		for (int i = 0; i < listCisel.size(); i++) {
			System.out.print(listCisel.get(i) + ",");
		}

		System.out.println();
		System.out.println("Seznam ��sel bez z�porn�ch");
		for (int i = 0; i < listCisel.size(); i++) {
			if (listCisel.get(i) < 0) {
				listCisel.remove(i);
				i--;
			}
		}

		for (int i = 0; i < listCisel.size(); i++) {
			System.out.print(listCisel.get(i) + ",");
		}

		System.out.println();
		System.out.println("_________________________________");
		System.out.println("Cvi�en� 3");
		System.out.println();

		ArrayList<Lednice> potraviny = new ArrayList<Lednice>();

		Lednice l1 = new Lednice("s�r", 254, 45);
		potraviny.add(l1);
		Lednice l2 = new Lednice("meloun", 140, 53);
		potraviny.add(l2);
		Lednice l3 = new Lednice("�okol�da", 550, 63);
		potraviny.add(l3);
		Lednice l4 = new Lednice("ml�ko", 192, 20);
		potraviny.add(l4);

		for (int i = 0; i < potraviny.size(); i++) {
			System.out.println(potraviny.get(i));
		}

		System.out.println();
		System.out.println("Po�et potravin v lednici: " + potraviny.size());
		System.out.println();

		int celkoveKalorie = 0;

		for (int i = 0; i < potraviny.size(); i++) {
			celkoveKalorie = celkoveKalorie + potraviny.get(i).getKalorie();
		}

		System.out.println("Celkov� po�et kalori�: " + celkoveKalorie);

		int celkovaCena = 0;

		for (int i = 0; i < potraviny.size(); i++) {
			celkovaCena = celkovaCena + potraviny.get(i).getCena();
		}
		System.out.println();
		System.out.println("Pr�m�rn� cena je: " + (double) celkovaCena / potraviny.size() + " k�");

	}

}
