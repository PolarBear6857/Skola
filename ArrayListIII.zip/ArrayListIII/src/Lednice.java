
public class Lednice {

	private String nazev;
	private int kalorie;
	private int cena;

	public Lednice(String nazev, int kalorie, int cena) {
		this.nazev = nazev;
		this.kalorie = kalorie;
		this.cena = cena;
	}

	public String getNazev() {
		return nazev;
	}

	public void setNazev(String nazev) {
		this.nazev = nazev;
	}

	public int getKalorie() {
		return kalorie;
	}

	public void setKalorie(int kalorie) {
		this.kalorie = kalorie;
	}

	public int getCena() {
		return cena;
	}

	public void setCena(int cena) {
		this.cena = cena;
	}

	public String toString() {
		return nazev + " obsahuje " + kalorie + " kalori� a stoj� " + cena + " k�";
	}

}
