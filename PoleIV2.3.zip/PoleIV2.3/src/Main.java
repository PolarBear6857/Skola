import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Cvi�en� 1");
		System.out.println();
		Scanner sc = new Scanner(System.in);
		System.out.println("Zadejte d�lku pole");
		int delkaPole = sc.nextInt();

		int[] pole = new int[delkaPole];

		for (int i = 0; i < pole.length; i++) {
			System.out.println("Zadejte " + (i + 1) + ". ��slo");
			pole[i] = sc.nextInt();
		}

		System.out.println();

		System.out.println("Zadan� ��sla");
		for (int i = 0; i < pole.length; i++) {
			System.out.print(pole[i] + ",");
		}

		System.out.println();
		System.out.println("_______________________________");
		System.out.println("Cvi�en� 2");
		System.out.println();

		System.out.println("Zadejte po�et �asopis�");
		int casopisyDelka = sc.nextInt();
		sc.nextLine();

		Casopis[] casopis = new Casopis[casopisyDelka];

		for (int i = 0; i < casopis.length; i++) {
			System.out.println("Zadejte jm�no �asopisu");
			String nazev = sc.nextLine();
			System.out.println("Zadejte cenu �asopisu");
			int cena = sc.nextInt();
			sc.nextLine();
			Casopis c = new Casopis(nazev, cena);
			casopis[i] = c;
		}

		System.out.println();

		for (int i = 0; i < casopis.length; i++) {
			System.out.println(casopis[i]);
		}
		System.out.println();

		System.out.println("�asopisy levn�j�� ne� 100 k�");
		for (int i = 0; i < casopis.length; i++) {
			if (casopis[i].getCena() <= 100) {
				System.out.print(casopis[i].getNazev() + ",");
			}
		}

		System.out.println();

		System.out.println("�asopisy dra��� ne� 100 k�");
		for (int i = 0; i < casopis.length; i++) {
			if (casopis[i].getCena() > 100) {
				System.out.print(casopis[i].getNazev() + ",");
			}
		}

		System.out.println();
		System.out.println("_______________________________");
		System.out.println("Cvi�en� 3");
		System.out.println();

		String[] text = new String[5];

		for (int i = 0; i < text.length; i++) {
			System.out.println("Zadejte text");
			text[i] = sc.nextLine();
		}

		System.out.println();
		System.out.println("Zadan� ��sla");
		for (int i = 0; i < text.length; i++) {
			System.out.print(text[i] + ",");
		}
		System.out.println();
		System.out.println();
		for (int i = 0; i < text.length; i++) {
			int opakovani = 0;
			for (int a = i + 1; a < text.length; a++) {
				if (text[i].equals(text[a])) {
					opakovani++;
				}
			}

			if (opakovani > 0) {
				System.out.println(text[i] + " se opakuje " + (opakovani + 1) + " kr�t");
			}

		}

	}

}
