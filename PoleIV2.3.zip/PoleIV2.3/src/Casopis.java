
public class Casopis {

	private String nazev;
	private int cena;
	
	public Casopis(String nazev, int cena) {
		this.nazev = nazev;
		this.cena = cena;
	}
	
	public String getNazev() {
		return nazev;
	}
	
	public void setNazev(String nazev) {
		this.nazev = nazev;
	}
	
	public int getCena() {
		return cena;
	}
	
	public void setCena(int cena) {
		this.cena = cena;
	}
	
	public String toString() {
		return "�asopis " + nazev + " stoj� " + cena + " k�";
	}
}
